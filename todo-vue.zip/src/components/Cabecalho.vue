<script setup>
    const props = defineProps(['tarefasPendentes'])
</script>

<template>
    <header class="p-5 mb-4 mt-4 bg-light rounded-3">
        <h1>Minhas tarefas</h1>
        <p>
            Você possui {{ props.tarefasPendentes }} tarefas pendentes <!-- tarefas pendentes  essa função muda a quantidade de tarefas-->
        </p>                                              <!-- de acordo com quantas tarefas vc adicionou -->
    </header>
</template>